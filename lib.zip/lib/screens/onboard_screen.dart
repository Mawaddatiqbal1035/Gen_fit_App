
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../core/utils/app_constants/app_assets/app_assets.dart';
import '../core/utils/app_constants/texts/app_authentication_texts_expanded.dart';

class OnBoardScreen extends StatefulWidget {

  const OnBoardScreen({super.key});

  @override
  State<OnBoardScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<OnBoardScreen> {
  @override
  Widget build(BuildContext context) {
    final s = MediaQuery.of(context).size;

    return SafeArea(
      child: Scaffold(
          backgroundColor:const Color(0xFFEEECEC),
          body: SingleChildScrollView(
              child: Center(
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              RichText(text: TextSpan(
                                  style: DefaultTextStyle.of(context).style.copyWith(
                                  ),
                                  children:[
                                    TextSpan(
                                        text: AppAuthenticationTextsExpanded.daily,
                                        style: TextStyle(
                                            fontSize: s.width*0.020+s.height*0.020,
                                            color:  const Color(0xFF9F7EFE),
                                            fontStyle: FontStyle.italic,
                                            fontWeight: FontWeight.bold
                                        )
                                    ),
                                    TextSpan(
                                        text: AppAuthenticationTextsExpanded.fitPlanner,
                                        style: TextStyle(
                                          fontSize: s.width*0.020+s.height*0.020,
                                          color: Colors.black,
                                          fontStyle: FontStyle.italic,
                                          fontWeight: FontWeight.bold,
                                        )
                                    )
                                  ]
                              ))
                            ],
                          ),
                          const SizedBox(height: 20),
                          // Correct usage of SvgPicture
                          SvgPicture.asset(
                            AppAssets.onBoardScreenAsset1,
                            height: s.height*0.250+s.width*0.200, // Adjust to fit screen
                            fit: BoxFit.contain,
                            theme: SvgTheme(
                              fontSize: s.height*20+s.width*0.20,
                            ),
                          ),
                          const SizedBox(height: 5),
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              shape: const CircleBorder(),
                              padding: const EdgeInsets.all(20),
                              shadowColor: Colors.grey,
                              elevation: 4.5,
                            ).copyWith(
                              fixedSize: MaterialStateProperty.all(Size(s.width*0.18,s.height*0.18)),
                                iconColor: WidgetStatePropertyAll(Colors.black)
                            ),
                            onPressed: () {
                              // Define button action here
                            },
                            child: const Icon(Icons.arrow_forward_outlined, size: 40),
                          ),
                          const SizedBox(height: 30),
                          Padding(
                            padding: const EdgeInsets.only(left: 70,right: 70),
                            child: LinearProgressIndicator(
                              backgroundColor: Colors.grey.withOpacity(0.4),
                              borderRadius: BorderRadius.circular(25),
                              color:  const Color(0xFF9F7EFE),
                              minHeight: 13,
                              value: 0.3,
                            ),
                          ),
                          const SizedBox(height: 30,),
                          Stack(
                              children: [ Flexible(
                                  child:Transform.rotate(angle: 3.14/14,
                                    child: Container(
                                      height: s.height*0.16,
                                      width: s.width*0.50,
                                      decoration: BoxDecoration(
                                          color: Colors.grey.shade200,
                                       borderRadius: const BorderRadius.only(
                                         topLeft: Radius.circular(2060),
                                         topRight: Radius.circular(1150),
                                         bottomLeft: Radius.circular(1000),
                                         bottomRight: Radius.circular(1050)
                                       )
                                     
      
                                      ),
                                    ),) ),
                                RichText(
                                  text: TextSpan(
                                    style: DefaultTextStyle.of(context).style.copyWith(fontSize: 28),
                                    children: [
                                      TextSpan(
                                        text: AppAuthenticationTextsExpanded.push,
                                        style: TextStyle(
                                          fontSize: s.width*0.025+s.height*0.025,
                                          color:  const Color(0xFF9F7EFE),
                                          fontStyle: FontStyle.italic,
                                          fontWeight: FontWeight.bold,
                                          shadows: [
                                            Shadow(
                                              blurRadius: 10.0,
                                              color: Colors.grey.withOpacity(0.5),
                                              offset: const Offset(3.0, 3.0),
                                            ),
                                          ],
                                        ),
                                      ),
                                      TextSpan(
                                        text: AppAuthenticationTextsExpanded.yourLimits,
                                        style: TextStyle(
                                          fontSize: s.width*0.023+s.height*0.023,
                                          color: Colors.black,
                                          fontStyle: FontStyle.italic,
                                          fontWeight: FontWeight.bold,
                                          shadows: [
                                            Shadow(
                                              blurRadius: 10.0,
                                              color: Colors.grey.withOpacity(0.5),
                                              offset: const Offset(3.0, 3.0),
                                            ),
                                          ],
                                        ),
                                      ),
                                      TextSpan(
                                        text: AppAuthenticationTextsExpanded.recordYourPersonalBest,
                                        style: TextStyle(
                                          fontSize: s.width*0.015+s.height*0.015,
                                          color: Colors.black,
                                          fontStyle: FontStyle.italic,
                                          shadows: [
                                            Shadow(
                                              blurRadius: 10.0,
                                              color: Colors.grey.withOpacity(0.5),
                                              offset: const Offset(3.0, 3.0),
                                            ),],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ]),
                          Padding(
                              padding: const EdgeInsets.only(left: 320),
                              child: ElevatedButton(onPressed: (){},
                                style:Theme.of(context).elevatedButtonTheme.style?.copyWith(
                                    fixedSize: MaterialStateProperty.all(
                                        Size(s.width*0.18, s.height*0.010))
                                ), child: Text(AppAuthenticationTextsExpanded.skip,
                                  style: Theme.of(context).textTheme.bodySmall?.
                                  copyWith(fontWeight: FontWeight.bold)),
                              )
      
                          )
      
                        ]), )))),
    );
  }
}