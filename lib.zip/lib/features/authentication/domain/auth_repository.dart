
import 'dart:async';


abstract class AuthRepository{

 // Future<Either<authFailure,userCredential>> login();

  //Future<Either<authFailure,void>> sendPasswordResetEmail(String eMail);

 // Future<void> enableLocalPersistence(Persistence persistence); // New method

}