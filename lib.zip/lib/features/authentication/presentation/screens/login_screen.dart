
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../controllers/onBoard_get_controller.dart';
import '../../../../core/utils/app_constants/app_assets/app_assets.dart';
import '../../../../core/utils/app_constants/texts/app_authentication_texts_expanded.dart';
import '../widgets/my_textfield_widget.dart';

class LoginScreen extends StatelessWidget {
  LoginScreen({super. key});

  final passwordTextController = TextEditingController();
  final eMailTextController = TextEditingController();
  bool rememberMe = false;
  @override
  Widget build(BuildContext context) {
    final s = MediaQuery.of(context).size;
    final onBoardGetController=Get.find<OnBoardGetController>();

    return SafeArea(
      child: Scaffold(
          backgroundColor: Colors.black,
          body: SingleChildScrollView(
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Login Button
                  Stack(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(top: 10),
                        child: Container(
                          width: s.width * 0.27,
                          height: s.height * 0.07,
                          decoration: BoxDecoration(
                            color: const Color(0xFFE8E4FF),
                            borderRadius: BorderRadius.circular(30),
                          ),
                          child: Center(
                            child: Text(
                              AppAuthenticationTextsExpanded.login,
                              style: Theme
                                  .of(context)
                                  .textTheme
                                  .bodySmall
                                  ?.copyWith(
                                fontWeight: FontWeight.bold,
                                fontSize: s.width * 0.020 + s.height * 0.020,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  // Image
                  Image.asset(
                    AppAssets.loginAsset,
                    height: s.height * 0.355,
                    width: s.width * 0.700,
                    fit: BoxFit.contain,
                  ),
                  const SizedBox(height: 1),
                  // Email TextField
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 50),
                    child: MyTextfieldWidget(
                      hintText: AppAuthenticationTextsExpanded.eMailHintText,
                      title: AppAuthenticationTextsExpanded.eMail,
                      errorMessage:AppAuthenticationTextsExpanded.invaildEmail,
                      controller: eMailTextController,

                    ),
                  ),
                  const SizedBox(height: 5),
                  // Password TextField
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 50),
                    child: MyTextfieldWidget(
                      hintText: AppAuthenticationTextsExpanded.passwordHintText,
                      title: AppAuthenticationTextsExpanded.password,
                      errorMessage: AppAuthenticationTextsExpanded.passwordNotMatch,
                      controller: passwordTextController,

                    ),),
                  const SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 50),
                        child: Row(
                          children: [
                            Checkbox(
                              value: rememberMe,
                              onChanged: (value) {
                                rememberMe = value!;
                              },
                            ),
                            Text(
                              AppAuthenticationTextsExpanded.rememberMe,
                              style: Theme
                                  .of(context)
                                  .textTheme
                                  .bodySmall
                                  ?.copyWith(
                                fontSize: s.width * 0.0080 +
                                    s.height * 0.0081,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(right: 50),
                        child: TextButton(
                          onPressed: () {},
                          child: Text(
                            AppAuthenticationTextsExpanded.forgetPassword,
                            style: Theme
                                .of(context)
                                .textTheme
                                .bodySmall
                                ?.copyWith(
                              fontSize: s.width * 0.0080 + s.height * 0.0081,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  ElevatedButton(
                    onPressed: () {
                      print('Pressed elevated button');
                      onBoardGetController.login(passw: passwordTextController.text,
                          userEmail: eMailTextController.text);
                    },
                    style: ElevatedButton.styleFrom(
                      shape: const CircleBorder(),
                      padding: const EdgeInsets.all(20),
                      shadowColor: Colors.grey,
                      elevation: 4.5,
                      fixedSize: Size(s.width * 0.19, s.height * 0.19),
                    ),
                    child: const Icon(Icons.login),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 70),
                    child: LinearProgressIndicator(
                      backgroundColor: Colors.grey.withOpacity(0.4),
                      color: const Color(0xFF9F7EFE),
                      borderRadius: BorderRadius.circular(25),
                      value: 0.9,
                      minHeight: 13,
                    ),
                  ),
                ],
              ),
            ),
          )
      ),
    );

  }
}
