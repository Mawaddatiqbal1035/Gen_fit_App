
import 'package:flutter/material.dart';
import '../../../../core/utils/app_constants/texts/app_authentication_texts_expanded.dart';
import '../widgets/my_textfield_widget.dart';

class ForgotPasswordScreen extends StatefulWidget {
  ForgotPasswordScreen({super.key});

  @override
  State<ForgotPasswordScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<ForgotPasswordScreen> {
  @override
  Widget build(BuildContext context) {
    final s = MediaQuery.of(context).size;
    final eMailController=TextEditingController();
    return Scaffold(
      backgroundColor: Color(0xFFEEECEC),
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment:   CrossAxisAlignment.start,
            children: [
              Stack(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 50,left: 9),
                    child: Text(
                      AppAuthenticationTextsExpanded.forgetPasswordText,
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        fontWeight: FontWeight.bold,
                        fontSize: s.width * 0.014 + s.height * 0.014,),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 10,),
              Padding(
                padding: const EdgeInsets.only(left: 9),
                child: Text(AppAuthenticationTextsExpanded.enterTheEmailAccount),
              ),
              SizedBox(height: 20),
              Padding(
                padding: const EdgeInsets.only(left: 10,right: 10),
                child: MyTextfieldWidget(hintText: AppAuthenticationTextsExpanded.forgetHintText, title: 'Email', errorMessage: 'invalid email',
                    controller: eMailController),
              ),
              SizedBox(height: 80),
              Padding(
                padding:  EdgeInsets.only(right: 28,left: 28),
                child: ElevatedButton(
                  onPressed: () {},
                  child: Text(AppAuthenticationTextsExpanded.sendCode),
                  style:ButtonStyle(
                    backgroundColor: WidgetStatePropertyAll(Colors.black),
                    fixedSize: WidgetStatePropertyAll(Size(s.width * 0.999, s.height * 0.017,)
                    ),

                  ),
                ),
              ) ],
          ),
        ),
      ),
    );
  }
}




