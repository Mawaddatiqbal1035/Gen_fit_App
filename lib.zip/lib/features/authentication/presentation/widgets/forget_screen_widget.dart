import 'package:flutter/material.dart';

class ForgetScreenWidget extends StatelessWidget {
  const ForgetScreenWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
