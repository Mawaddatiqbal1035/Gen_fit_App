import 'package:either_dart/either.dart';
import 'package:gen_fit/features/ai_workout_recommendication/domain/entinties/exercise_entity.dart';
import '../../../../core/error_handling/failure.dart';
import '../repositories/exercise_repository.dart';

class ExerciseUseCase{
   ExerciseRepository exerciseRepository;
  ExerciseUseCase({required this.exerciseRepository});


  Stream<Either<Failure, ExerciseEntity>> execute() async*{
    try {
      while (true) {
       yield* await exerciseRepository.execute();
      }
    }catch(error){
      yield Left(Failure(error.toString()));
    }
  }
}