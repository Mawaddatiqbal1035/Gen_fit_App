import 'package:either_dart/either.dart';
import 'package:gen_fit/features/ai_workout_recommendication/presentation/controllers/pickImage.dart';
import '../../../../core/error_handling/failure.dart';
import '../../data/data-sources/exercise_api_data_source.dart';
import '../../data/repositories/exercise_repository_imp.dart';
import '../entinties/exercise_entity.dart';


abstract class ExerciseRepository{
 factory  ExerciseRepository({required ExerciseApiDataSource dataSource}){
   return ExerciseRepositoryImpl(dataSource: dataSource, pickimageController: PickImage());
 }

  Stream<Either<Failure,ExerciseEntity>> execute();


}