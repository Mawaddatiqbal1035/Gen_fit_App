import 'dart:async';
import 'package:either_dart/either.dart';
import 'package:gen_fit/features/ai_workout_recommendication/domain/entinties/exercise_entity.dart';
import 'package:gen_fit/features/ai_workout_recommendication/domain/usecase/exercise_use_case.dart';
import 'package:get/get.dart';
import '../../../../core/error_handling/failure.dart';

class YoutubeController extends GetxController{
  final isLoading =false.obs;
  final errorMessage=''.obs;
  final isError=false.obs;
YoutubeController(  this.exerciseUseCase);
final ExerciseUseCase exerciseUseCase;
  StreamSubscription<Either<Failure, ExerciseEntity>>? streamSubscription;
  Rx<ExerciseEntity?> weatherEntity = Rxn<ExerciseEntity>();
  var workoutPrediction = ''.obs;
  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    fetchYoutubeVideo(workoutPrediction.value);
  }
  fetchYoutubeVideo(Object workoutPrediction) async* {
    isLoading.value=true;
    isError.value=false;

  streamSubscription =await exerciseUseCase.execute().listen((result){
    result.fold((failure){
      isLoading.value=false;
      isError.value=true;
      errorMessage.value=failure.errorMessage;
    },(success){
      isLoading.value=false;
      isError.value=false;
      weatherEntity.value=success;
    });
  });

  }
  @override
  void onClose() {
    // TODO: implement onClose
    streamSubscription?.cancel();
    super.onClose();
  }
}