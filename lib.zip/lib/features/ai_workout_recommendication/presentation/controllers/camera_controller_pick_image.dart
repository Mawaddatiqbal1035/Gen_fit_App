import 'package:gen_fit/features/ai_workout_recommendication/presentation/controllers/youtube_controller.dart';
import 'package:gen_fit/features/ai_workout_recommendication/presentation/controllers/youtube_fetch_video.dart';
import 'package:google_generative_ai/google_generative_ai.dart';
import 'package:image_picker/image_picker.dart';
import 'package:get/get.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';

class CameraControllerPickImage extends GetxController {
  CameraControllerPickImage(this.youtubeController);
  final String apiKey = 'AIzaSyAZ-xy21dRcNUCEOqxFbNw1paI4K1phkms';
  YoutubeController youtubeController;
  XFile?  pickedFile;
  @override
  void onInit() {
    super.onInit();
    // Dependency injection via GetX for CameraControllerPickImage
    handleWorkoutAnalysisAndFetchVideo();
  }

  /// Single function to handle image pick from either gallery or camera, model analysis, and YouTube video fetch
  Future<void> handleWorkoutAnalysisAndFetchVideo() async {
    try {
      // Step 1: Pick the image (Allow user to choose from camera or gallery)
      final pickedFile = await pickImage();
      if (pickedFile == null) {
        print("No image selected.");
        return;
      }

      // Step 2: Analyze the image with Gemini model
      final prompt = pickedFile.path;
      final imageBytes = await pickedFile.readAsBytes();

      final model = GenerativeModel(
        model: "gemini-1.5-flash",
        apiKey: apiKey,
      );

      final result = await model.generateContent([
        Content.model([DataPart(prompt, imageBytes)]),
      ]);

      // Step 3: Extract workout prediction from Gemini response
      final workoutPrediction = extractWorkoutPrediction(result);

      // Step 4: Fetch YouTube video based on workout prediction
      youtubeController.fetchYoutubeVideo(workoutPrediction);
    } catch (error) {
      print("Error: $error");
    }
  }

  // Step to choose image from camera or gallery
  Future<XFile?> pickImage() async {
    final ImagePicker imagePicker = ImagePicker();

    // Here you can show a dialog to the user to pick the source (camera or gallery)
    final ImageSource source = await showImageSourceDialog();

    pickedFile = await imagePicker.pickImage(source: source);
    return pickedFile;
  }

  // Show dialog to let user choose between camera and gallery
  Future<ImageSource> showImageSourceDialog() async {
    // For the sake of this example, let's assume we default to camera.
    // You can replace this with a proper dialog to let the user choose.
    return Future.value(
      ImageSource.camera, // You can also return ImageSource.gallery here based on your need.
    );
  }

  // Extract workout prediction from result
  Object extractWorkoutPrediction(GenerateContentResponse result) {
    if (result.candidates.isNotEmpty) {
      return result.candidates.first.content ?? '';
    }
    return 'No workout prediction found';
  }
}