/*import 'package:gen_fit/features/ai_workout_recommendication/data/data-sources/exercise_api_data_source.dart';
import 'package:get/get.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';

class YoutubeFetchVideo extends GetxController {
  YoutubeFetchVideo(this.exerciseApiDataSource);

  final ExerciseApiDataSource exerciseApiDataSource;

  // Make the controller reactive
  Rxn<YoutubePlayerController> youtubePlayerController = Rxn<YoutubePlayerController>();

  void fetchYoutubeVideo(workoutPrediction) {
    youtubePlayerController.value = YoutubePlayerController(
      initialVideoId: exerciseApiDataSource.channelId, // Make sure this is a valid YouTube video ID
      flags: const YoutubePlayerFlags(
        isLive: false,
        autoPlay: true,
        mute: false,
      ),
    );
  }
}*/
