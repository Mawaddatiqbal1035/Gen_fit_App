/*import 'package:gen_fit/features/ai_workout_recommendication/domain/usecase/exercise_use_case.dart';
import 'package:get/get.dart';
import 'package:google_generative_ai/google_generative_ai.dart';
import 'package:image_picker/image_picker.dart';
import 'camera_controller_pick_image.dart';
import 'youtube_controller.dart';

class GeminiController extends GetxController {
  final String apiKey = 'AIzaSyAZ-xy21dRcNUCEOqxFbNw1paI4K1phkms';
  late final CameraControllerPickImage cameraControllerPickImage;
  final YoutubeController youtubeController = Get.find<YoutubeController>();

  @override
  void onInit() {
    super.onInit();
  }

  /// Predict workout using Gemini Model and trigger YouTube video search
  Future<void> predictWorkout() async {
    final model = GenerativeModel(
      model: "gemini-pro-vision",
      apiKey: apiKey,
    );

    try {
      final prompt = cameraControllerPickImage.imageFile?.path;
      final imageBytes = await cameraControllerPickImage.imageFile?.readAsBytes();

      // Send the image data for analysis using Gemini
      final result = await model.generateContent([
        Content.model([DataPart(prompt!, imageBytes!)]),
      ]);

      final workoutPrediction = _extractWorkoutPrediction(result);

      youtubeController.fetchYoutubeVideo();
    } catch (error) {
      print("Error during Gemini prediction: $error");
    }
  }
  Object _extractWorkoutPrediction(GenerateContentResponse result) {
    return result.candidates.first.content?? '';
  }
}*/
