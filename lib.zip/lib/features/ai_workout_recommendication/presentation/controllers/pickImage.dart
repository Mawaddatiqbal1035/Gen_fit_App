import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';

class PickImage extends GetxController {
  XFile? fileImage;
  ImagePicker imagePicker = ImagePicker();

  Future<XFile?> pickImage(ImageSource source) async {
    // Pick the image from the given source (camera or gallery)
    final XFile? pickedFile = await imagePicker.pickImage(source: source);

    if (pickedFile != null) {
      fileImage = pickedFile; // Store the picked image file
    }

    return pickedFile; // Return the picked image file
  }
}
