
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import '../../../../core/shared_features/theme_management/data/repositories/theme_repository_impl.dart';
import '../../../../core/shared_features/theme_management/domain/usecase/theme_usecase.dart';
import '../../../../core/shared_features/theme_management/presentation/controllers/theme_controller.dart';

class HomeScreenDrawerWidget extends StatelessWidget {
   HomeScreenDrawerWidget({super.key});
  @override
  Widget build(BuildContext context) {
    Get.put(ThemeController(ThemeUseCase(ThemeRepositoryImpl(GetStorage()))));
    final themeController=Get.find<ThemeController>();
    return Drawer(
      child: ListView(
                  children: [
                    DrawerHeader(
                      child: ListTile(title: Container(
                        height: 80,
                        child: const Column(
                          children: [
                            CircleAvatar(
                              child: Icon(Icons.person,size: 60,),
                            ),
                            Center(child: Text("UserName")),
                          ],
                        ),
                      ),
                      ),
                    ),
                    ListTile(
                     title:  Text("ThemeMode"),
                   trailing:    CupertinoSwitch(
                         value: Theme.of(context).brightness==Brightness.dark, onChanged: (newTheme) {
                       themeController.toggleTheme();
                     })
                   ),
                    ListTile(title: const Text("Logout"),
                    trailing: IconButton(onPressed: (){}, icon: Icon(Icons.logout)),)

                  ]),
        );
  }
}
