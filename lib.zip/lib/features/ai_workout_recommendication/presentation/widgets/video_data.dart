/*import 'package:flutter/cupertino.dart';

class VideoData extends StatelessWidget {
  final dynamic url;
  const VideoData({super.key,required this.url});

  @override
  Widget build(BuildContext context) {
    return WebviewScaffold(url: url);
  }
}*/
