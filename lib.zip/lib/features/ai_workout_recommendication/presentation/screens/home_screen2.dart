import 'package:flutter/material.dart';
import 'package:gen_fit/features/ai_workout_recommendication/domain/repositories/exercise_repository.dart';
import 'package:gen_fit/features/ai_workout_recommendication/domain/usecase/exercise_use_case.dart';
import 'package:gen_fit/features/ai_workout_recommendication/presentation/controllers/youtube_controller.dart';
import 'package:gen_fit/widgets/daily_workout_widget2.dart';
import 'package:get/get.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';
import '../controllers/youtube_fetch_video.dart';
import '../controllers/camera_controller_pick_image.dart';
import '../widgets/home_screen_drawer_widget.dart';
import 'package:gen_fit/features/ai_workout_recommendication/data/data-sources/exercise_api_data_source.dart';

class HomeScreen2 extends StatelessWidget {
  const HomeScreen2({super.key});

  @override
  Widget build(BuildContext context) {
    final s = MediaQuery.of(context).size;
    final CameraControllerPickImage cameraControllerPickImage = Get.put(
      CameraControllerPickImage(YoutubeController(ExerciseUseCase(
          exerciseRepository: ExerciseRepository(dataSource: ExerciseApiDataSource())))),
    );

    return SafeArea(
      child: Scaffold(
        drawer: HomeScreenDrawerWidget(),
        body:CustomScrollView(slivers: [
              SliverAppBar(
                title: Text(
                  'Home',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    fontSize: s.width * 0.03 + s.height * 0.020,
                  ),
                ),
                centerTitle: true,
                elevation: 0,
              ),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'All Workouts',
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          fontSize: s.width * 0.03 + s.height * 0.020,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SliverList(
                delegate: SliverChildBuilderDelegate(
                      (context, index) {
                    return Padding(
                      padding: const EdgeInsets.only(top: 14),
                      child: cameraControllerPickImage.pickedFile == null
                          ? const Center(child: Text("No image selected"))
                          : Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(right: 250),
                            child: ElevatedButton(
                              onPressed: () {},
                              style: ButtonStyle(
                                fixedSize: WidgetStateProperty.all(
                                    Size(s.width * 0.38, s.height * 0.027)),
                                backgroundColor:
                                WidgetStateProperty.all(const Color(0xFFE8E4FF)),
                              ),
                              child: Text(
                                'Recommended',
                                style: Theme.of(context).textTheme.bodySmall,
                              ),
                            ),
                          ),
                          const SizedBox(height: 60),
                          Text("Fetch Exercises")
                        ],
                      ),
                    );
                  },
                  childCount: 1,
                ),
              ),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 30),
                  child: Row(
                    children: [
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: ElevatedButton(onPressed: (){}, child: Text("PickImage"))
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ])
            ),
          );
        }
  }
