import 'package:cross_file/src/types/interface.dart';
import 'package:either_dart/either.dart';
import 'package:gen_fit/features/ai_workout_recommendication/presentation/controllers/pickImage.dart';
import '../../../../core/error_handling/failure.dart';
import '../../domain/entinties/exercise_entity.dart';
import '../../domain/repositories/exercise_repository.dart';
import '../data-sources/exercise_api_data_source.dart';
import '../models/exercise_data_model.dart';

class ExerciseRepositoryImpl implements ExerciseRepository{
  final ExerciseApiDataSource dataSource;

 final PickImage pickimageController;
ExerciseRepositoryImpl({required this.dataSource,required this.pickimageController});

ExerciseEntity  exerciseConvertor(ExerciseDataModel exerciseModel){
   return ExerciseEntity
     (
     widthStandard: exerciseModel.widthStandard,
     widthMedium: exerciseModel.widthMedium,
     widthMaxres: exerciseModel.widthMaxres,
     titleLocalized: exerciseModel.titleLocalized,
     publishedAt: exerciseModel.publishedAt,
     kind: exerciseModel.kind,
     heightStandard: exerciseModel.heightStandard,
     heightMedium: exerciseModel.heightMedium,
     heightMaxres: exerciseModel.heightMaxres,
     heightHigh: exerciseModel.heightHigh,
     heightDefault: exerciseModel.heightDefault,
     descriptionLocalized: exerciseModel.descriptionLocalized,
     channelTitle: exerciseModel.channelTitle,
     channelId: exerciseModel.channelTitle,
     title: exerciseModel.title,
     itemCount: exerciseModel.itemCount,
     urlDefault: exerciseModel.urlDefault,
     widthDefault: exerciseModel.widthDefault,
     urlHigh: exerciseModel.urlHigh,
     widthHigh: exerciseModel.widthHigh,
      etag: exerciseModel.etag,
     urlMaxres: exerciseModel.urlMaxres,
     urlMedium: exerciseModel.urlMedium,
     urlStandard: exerciseModel.urlStandard,
     description: exerciseModel.description,
     id: exerciseModel.id
   );
}

  @override
  Stream<Either<Failure,ExerciseEntity>> execute() async*{
  try {
    // TODO: implement fetchExercise
    final exerciseDataModel = await dataSource.fetchExercise(pickimageController.fileImage?.path as XFile);
    final exerciseEntity = exerciseConvertor(exerciseDataModel);
    yield Right(exerciseEntity);
  }catch(failure){
    yield Left(Failure(failure.toString()));
  }
  }
  }
