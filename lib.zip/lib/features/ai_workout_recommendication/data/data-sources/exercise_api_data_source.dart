import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import '../models/exercise_data_model.dart';

class ExerciseApiDataSource {
  ExerciseApiDataSource();

  final String apiKey = 'AIzaSyBvOa-4tv-0PhjNjR8ZiLV35SB-T-hYvv4';

  Future<ExerciseDataModel> fetchExercise(XFile imageFile) async {
    try {
      final Uri url = Uri.parse(
          'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro-vision:generateContent?key=$apiKey');
      final File file = File(imageFile.path);
      final List<int> imageBytes = await file.readAsBytes();
      final String base64Image = base64Encode(imageBytes);

      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'contents': [
            {
              'parts': [
                {
                  'inline_data': {
                    'mime_type': 'image/jpeg',
                    'data': base64Image
                  }
                },
                {'text': 'Is image me kya dikh raha hai?'}
              ]
            }
          ]
        }),
      );

      if (response.statusCode == 200) {
        final json = jsonDecode(response.body);
        print(json);
        return ExerciseDataModel.toJson(json);
      } else {
        throw Exception("Error ${response.statusCode}: ${response.body}");
      }
    } catch (e) {
      throw Exception("Failed to fetch exercise: ${e.toString()}");
    }
  }
}
