class ExerciseDataModel {
  String id;
  String channelId;
  String title;
  String channelTitle;
  String description;
  String descriptionLocalized;
  String etag;
  int heightDefault;
  int widthDefault;
  String urlDefault;
  int heightMedium;
  int widthMedium;
  String urlMedium;
  int heightHigh;
  int widthHigh;
  String urlHigh;
  int heightStandard;
  int widthStandard;
  String urlStandard;
  int heightMaxres;
  int widthMaxres;
  String urlMaxres;
  String titleLocalized;
  String kind;
  String publishedAt;
  int itemCount;

  ExerciseDataModel({
    required this.id,
    required this.channelId,
    required this.title,
    required this.channelTitle,
    required this.description,
    required this.descriptionLocalized,
    required this.etag,
    required this.heightDefault,
    required this.heightMedium,
    required this.heightHigh,
    required this.heightStandard,
    required this.heightMaxres,
    required this.itemCount,
    required this.kind,
    required this.publishedAt,
    required this.urlDefault,
    required this.urlMedium,
    required this.urlHigh,
    required this.urlStandard,
    required this.urlMaxres,
    required this.widthDefault,
    required this.widthMedium,
    required this.widthHigh,
    required this.widthStandard,
    required this.widthMaxres,
    required this.titleLocalized,
  });

  factory ExerciseDataModel.toJson(Map<String, dynamic> json) {
    var item = json['items'][0]; // Access first item

    return ExerciseDataModel(
      id: item['id'],
      channelId: item['snippet']['channelId'],
      title: item['snippet']['title'],
      channelTitle: item['snippet']['channelTitle'],
      description: item['snippet']['description'],
      descriptionLocalized: item['snippet']['localized']['description'],
      etag: item['etag'],
      kind: item['kind'],
      publishedAt: item['snippet']['publishedAt'],
      itemCount: item['contentDetails']['itemCount'],

      // Thumbnails
      urlDefault: item['snippet']['thumbnails']['default']['url'],
      widthDefault: item['snippet']['thumbnails']['default']['width'],
      heightDefault: item['snippet']['thumbnails']['default']['height'],

      urlMedium: item['snippet']['thumbnails']['medium']['url'],
      widthMedium: item['snippet']['thumbnails']['medium']['width'],
      heightMedium: item['snippet']['thumbnails']['medium']['height'],

      urlHigh: item['snippet']['thumbnails']['high']['url'],
      widthHigh: item['snippet']['thumbnails']['high']['width'],
      heightHigh: item['snippet']['thumbnails']['high']['height'],

      urlStandard: item['snippet']['thumbnails']['standard']['url'],
      widthStandard: item['snippet']['thumbnails']['standard']['width'],
      heightStandard: item['snippet']['thumbnails']['standard']['height'],

      urlMaxres: item['snippet']['thumbnails']['maxres']['url'],
      widthMaxres: item['snippet']['thumbnails']['maxres']['width'],
      heightMaxres: item['snippet']['thumbnails']['maxres']['height'],

      titleLocalized: item['snippet']['localized']['title'],
    );
  }
}
