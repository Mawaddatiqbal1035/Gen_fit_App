class AppAssets{
  static const onBoardScreenAsset1='assets/fitness.svg';
  static const onBoardScreenAsset2='assets/Running.svg';
  static const loginAsset='assets/img.png';
  static const signUpAsset='assets/img.png';
  static const homeScreenWorkoutAsset1='assets/Road.svg';
  static const homeScreenWorkoutAsset2='assets/Workout.svg';
  static const homeScreenWorkoutAsset3='assets/Stretch.svg';
}