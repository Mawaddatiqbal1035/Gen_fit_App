class Failure{
  var errorMessage;

  Failure(this.errorMessage);
}